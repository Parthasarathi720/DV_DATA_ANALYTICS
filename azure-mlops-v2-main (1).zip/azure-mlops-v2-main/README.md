E2E Azure Mlops deployment using Github Action
